﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SortingVisualization
{
    public class SelectionSort : Form
    {
        public static int counter = 0;
        public static int smallest = 0;
        public static int j = 0;

        public static List<int> numbers = new List<int>();
        public static List<Label> labels = new List<Label>();
        private static Form2 form = new Form2();

        private static Color[] colors = new Color[]
        {
            Color.LightGreen, //sorted item color
            Color.Gray,       //selected item color 
            Color.Blue,       //smallest item color
            Color.Red         //not sorted item color
        };


        public static void Sort(List<int> numbers, ref int counter)
        {
            for (; counter < numbers.Count;)
            {
                SelectionSort.counter = counter;
                Create(form);
                smallest = counter;
                for (j = counter + 1; j < numbers.Count; j++)
                {
                    if (numbers[j] < numbers[smallest])
                        smallest = j;
                    Create(form);
                }
                swap();
                break;
            }
        }
        private static void swap()
        {
            Create(form);
            int temp = numbers[smallest];
            numbers[smallest] = numbers[counter];
            numbers[counter] = temp;
        }

        private static bool isSorted()
        {
            for (int i = 1; i < numbers.Count; i++)
                if (numbers[i - 1] > numbers[i])
                    return false;
            return true;
        }
        public static void Create(Form2 form2)
        {
            form = form2;
            foreach (Control item in form.Controls)
            {
                if (item is Button)
                    continue;
                else form.Controls.Remove(item);
            }
            labels.Clear();
            build(form);
        }
        private static void build(Form2 form)
        {
            if(j == numbers.Count || j==0)
                for (int i = 0; i < numbers.Count; i++)
                {
                    Label label = new Label();
                    label.Text = numbers[i].ToString();
                    label.AutoSize = false;
                    label.BorderStyle = BorderStyle.FixedSingle;

                    if (i != counter && i != smallest)
                        label.BackColor = colors[3];
                    if (i == smallest)
                        label.BackColor = colors[2];
                    if (i == counter)
                        label.BackColor = colors[1];
                    if (i == smallest && i == counter && j!=0)
                        label.BackColor = colors[2];
                    if (i < counter || isSorted())
                        label.BackColor = colors[0];

                    if (i != 0)
                    {
                        var x = labels[i - 1].Location.X;
                        var y = labels[0].Location.Y;
                        label.Location = new Point(x += 50, y);
                    }

                    switch (numbers[i])
                    {
                        case 1:
                            label.Size = new Size(40, numbers[i] * 14);
                            break;
                        case 2:
                            label.Size = new Size(40, numbers[i] * 8);
                            break;
                        default:
                            label.Size = new Size(40, numbers[i] * 6);
                            break;
                    }
                    labels.Add(label);
                    form.Controls.Add(label);
                }
        }
    }
}
      
